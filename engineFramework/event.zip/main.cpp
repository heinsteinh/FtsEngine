/*
 * some example usage code
 */

#include "eventchannel.h"
#include <string>
#include <iostream>

struct Dummy {};
struct IntTransport { int i; };
struct StringTransport { std::string message; };
	
struct DummyHandler {
	void handle(const Dummy& d) {
		std::cout << "Dummy!" << std::endl;
	}
};

struct DoubleHandler {
	void handle(const IntTransport& i) {
		std::cout << "Int: " << i.i << std::endl;
	}
	
	void handle(const StringTransport& s) {
		std::cout << "Message: " << s.message << std::endl;
	}
};

struct PtrHandler {
	void handle(const StringTransport* ps) {
		std::cout << "(Ptr) Message: " << ps->message << std::endl;
	}
};

EventChannel chan;
	
Dummy dummy;
IntTransport inty;
StringTransport str;
StringTransport* strptr;

void broadcast(const std::string& message) {
	std::cout << message << std::endl;
	chan.broadcast(dummy);
	chan.broadcast(inty);
	chan.broadcast(str);
	chan.broadcast(strptr);
	std::cout << "Done" << std::endl << std::endl;
}

int main() {
	strptr = new StringTransport();
	
	inty.i = 5;
	str.message = "Testing 123";
	strptr->message = "Ptr!";

	broadcast("No receivers");

	DummyHandler dummy_handler;
	DoubleHandler double_handler;
	PtrHandler ptr_handler;

	chan.add<Dummy>(dummy_handler);
	chan.add<IntTransport>(double_handler);
	chan.add<StringTransport>(double_handler);
	chan.add<StringTransport*>(ptr_handler);
	
	broadcast("All receivers");

	chan.remove<StringTransport>(double_handler);

	broadcast("Minus one");

	delete strptr;
	
	return 0;
}