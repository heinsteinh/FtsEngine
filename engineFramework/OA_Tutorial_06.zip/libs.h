#ifndef OA_LIBS_H
#define OA_LIBS_H

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <map>
#include <string>

#include <boost/shared_ptr.hpp>

#endif