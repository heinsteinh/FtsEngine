#pragma once
class TestEntity
{
public:
	TestEntity();
	~TestEntity();
};

