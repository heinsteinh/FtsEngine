#pragma once


#include <string>
#include <cstdint>
#include <memory>

namespace core
{
	class  Window 
	{
	public:
		friend class Video;

		typedef std::shared_ptr<Window> WindowPtr;

		enum eWindowType : std::uint8_t 
		{
			GLFW = 0,
			QT = 1
		};

		Window(const std::string& title, eWindowType type) : mTitle(title), mWindowType(type), mTimeElapsedSinceLastFrame(0.0) {}
		virtual ~Window() {}

		virtual void render(double) = 0;
		virtual void update(double) = 0;
		virtual bool create() = 0;
		virtual void destroy() = 0;

		const eWindowType& type() { return mWindowType; }

	

		//protected:
		virtual bool isClosed() { return false; };

		virtual void run() = 0;


		unsigned int mWidth;
		unsigned int mHeight;

		bool mFullScreen;
		std::string mTitle;

		eWindowType mWindowType;

		double mTimeElapsedSinceLastFrame;
	};

}