#include "stdafx.h"
#include "Application.h"


namespace app 
{
	Application::Application(const std::string& name, unsigned int taskFlags) :
		core::System(name, taskFlags)
	{
	}


	Application::~Application() 
	{
	}
}

