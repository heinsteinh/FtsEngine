#pragma once

#include "System.h"

namespace core {
	class Engine;
}

namespace app {
	class Application : public core::System
	{
	public:
		friend class core::Engine;
		typedef std::shared_ptr<app::Application> ApplicationPtr;

		Application(const std::string& name, unsigned int taskFlags = core::Task::SINGLETHREADED_REPEATING);
		virtual ~Application();

	protected:
		core::Engine* mEngine;
	};
}

