#include "stdafx.h"
#include "Input.h"
#include "eventchannel.h"




namespace input
{
	Input::Input()
		: core::System("Input", core::Task::NONE)
		, mTouch(new TouchCallback())
		, mKeyboard(new Keyboard())
	{
			core::EventChannel chan;
			chan.add<video::VideoSystem::WindowCreated>(*this);
		}

	Input::~Input()
	{
	}


	bool Input::init() 
	{
		return true;
	}

	void Input::run() 
	{

	}

	void Input::handle(const video::VideoSystem::WindowCreated&)
	{



		glfwSetKeyCallback(&mKeyboard->glfwKeyboardCallback);
		
	

		//glfwSetMousePosCallback(&mMouse->glfwMousePosCallback);
		//glfwSetMouseButtonCallback(&mMouse->glfwMouseButtonCallback);
		//glfwSetMouseWheelCallback(&mMouse->glfwMouseWheelCallback);
	}

	void Input::shutdown()
	{
		glfwSetKeyCallback();

		//glfwSetMousePosCallback(NULL);
		//glfwSetMouseButtonCallback(NULL);
		//glfwSetMouseWheelCallback(NULL);
	}


	const std::shared_ptr<Keyboard>& Input::getKeyboard()
	{
		return mKeyboard;
	}


	const std::shared_ptr<TouchCallback>& Input::getTouch()
	{
		return mTouch;
	}
}
