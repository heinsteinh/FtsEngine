// engineFramework.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"


#include <iostream>

#include "eventbridge.h"
#include "eventhandler.h"
#include "eventchannel.h"

#include "task.h"
#include "taskmanager.h"


#include "System.h"
#include "Engine.h"


#include "VideoSystem.h"
#include "Application.h"

#include <time.h>       /* time */
#include <stdlib.h>     /* srand, rand */


namespace test_framework
{
	/*
	struct Dummy {};
	struct IntTransport { int i; };
	struct StringTransport { std::string message; };

	struct DummyHandler {
	void handle(const Dummy& d) {
	std::cout << "Dummy!" << std::endl;
	}
	};

	struct DoubleHandler {
	void handle(const IntTransport& i) {
	std::cout << "Int: " << i.i << std::endl;
	}

	void handle(const StringTransport& s) {
	std::cout << "Message: " << s.message << std::endl;
	}
	};

	struct PtrHandler {
	void handle(const StringTransport* ps) {
	std::cout << "(Ptr) Message: " << ps->message << std::endl;
	}
	};

	EventChannel chan;

	Dummy dummy;
	IntTransport inty;
	StringTransport str;
	StringTransport* strptr;

	void broadcast(const std::string& message)
	{
	std::cout << message << std::endl;
	chan.broadcast(dummy);
	chan.broadcast(inty);
	chan.broadcast(str);
	chan.broadcast(strptr);
	std::cout << "Done" << std::endl << std::endl;
	}*/

}

namespace test
{
	class TestSystem : public core::System
	{

	public:
		typedef std::shared_ptr<test::TestSystem> TestSystemPtr;


		struct PreUpdate{};

	public:
		TestSystem() :System("TestSystem")
		{
			enableUpdater();
			mSomeConfigSetting = 10;
			addSetting("SomeConfigSetting", &mSomeConfigSetting);
		}

		virtual ~TestSystem()
		{
		}

		virtual void update()
		{
			std::cout << "Update TestSystem ." << mSomeConfigSetting++ << " " << std::endl;

			if (mSomeConfigSetting > 30)
			{
				mChannel.broadcast(core::TaskManager::StopEvent());
			}

			input::TouchEvent evt;
			evt.phase = (input::TouchEvent::Phase)(rand() % 4);// input::TouchEvent::BEGAN ;
			mEngine->getInput()->getTouch()->TouchPosCallback_evt(evt);

			std::this_thread::sleep_for(std::chrono::milliseconds(500));
		}

		unsigned int mSomeConfigSetting;

		// Event handlers
		void touchesBeganHandler(const input::TouchEvent& touches)
			//void touchesBeganHandler(const std::vector<input::TouchEvent>& touches)
		{}
		void touchesEndedHandler(const std::vector<input::TouchEvent>& touches)
		{}
		void touchesMovedHandler(const std::vector<input::TouchEvent>& touches)
		{}


	};
}





int _tmain(int argc, _TCHAR* argv[])
{
	/*
	strptr = new StringTransport();

	inty.i = 5;
	str.message = "Testing 123";
	strptr->message = "Ptr!";

	broadcast("No receivers");

	DummyHandler dummy_handler;
	DoubleHandler double_handler;
	PtrHandler ptr_handler;

	chan.add<Dummy>(dummy_handler);
	chan.add<IntTransport>(double_handler);
	chan.add<StringTransport>(double_handler);
	chan.add<StringTransport*>(ptr_handler);

	broadcast("All receivers");

	chan.remove<StringTransport>(double_handler);

	broadcast("Minus one");

	delete strptr;
	*/




	try {

		srand(time(NULL));

		gLog.add(new std::ofstream("global.log"));

		gLog << "Starting Overdrive Assault...";

		test::TestSystem::TestSystemPtr  testApp(new test::TestSystem());
		//app::Application::ApplicationPtr  app(new app::Application("MyApplication"));

		//Entry point, main module of this framework
		core::Engine mEngine;
		mEngine.windowCreationHint(core::Engine::USE_QT); //use Qt



		//mEngine.setApplication(app);
		mEngine.add(testApp);

		mEngine.run();

		gLog << "Shutting down";
	}
	catch (std::exception e)
	{
		std::cerr << e.what() << std::endl;
	}
	catch (...) {
		std::cerr << "Unknown exception" << std::endl;
	}


	return 0;
}

