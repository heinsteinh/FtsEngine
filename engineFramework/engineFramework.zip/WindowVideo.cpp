#include "stdafx.h"
#include "WindowVideo.h"


