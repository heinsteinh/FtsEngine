#include "stdafx.h"
#include "TestEntity.h"


TestEntity::TestEntity()
{
}


TestEntity::~TestEntity()
{
}
