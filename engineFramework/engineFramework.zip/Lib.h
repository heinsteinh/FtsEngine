/*
* Includes all relevant libraries
*/

#ifndef OA_LIBS_H
#define OA_LIBS_H

#include <ctime>
#include <deque>
#include <fstream>
#include <iostream>
#include <list>
#include <map>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <vector>


#include <thread>
#include <future>
#include <functional>


/*
#include <boost/bind.hpp>
#include <boost/enable_shared_from_this.hpp>
//#include <boost/filesystem.hpp>
#include <boost/function.hpp>
#include <boost/function_equal.hpp>
#include <boost/graph/adjacency_list.hpp>
#include <boost/graph/topological_sort.hpp>
#include <boost/graph/depth_first_search.hpp>
#include <boost/graph/dijkstra_shortest_paths.hpp>
#include <boost/graph/graph_traits.hpp>
#include <boost/graph/visitors.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/pointer_cast.hpp>
//#include <boost/program_options.hpp>
#include <boost/scoped_ptr.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/shared_array.hpp>
#include <boost/thread.hpp>
#include <boost/utility.hpp>
#include <boost/weak_ptr.hpp>
*/

#endif

