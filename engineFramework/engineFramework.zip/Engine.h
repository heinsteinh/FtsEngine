#pragma once



#include <string>
#include <cstdint>

#include "taskmanager.h"

#include "System.h"
#include "ConfigSystem.h"
#include "VideoSystem.h"
#include "Input.h"

#include "Clock.h"

#include "Application.h"

namespace core 
{
	
	
	class  Engine 
	{
	public:
		typedef std::shared_ptr<System> SystemPtr;
		typedef std::map<std::string, SystemPtr> SystemMap;


		enum eWindowLibraryType : std::int8_t 
		{
			USE_GLFW3 = 0,
			USE_QT = 1
		};
		
		void windowCreationHint(eWindowLibraryType windowLibrary)
		{
			if (!mbRunning)
				mWindowLibrary = windowLibrary;
		}

		const eWindowLibraryType& windowType() { return mWindowLibrary; }


		struct TimeUpdater : public Task 
		{
			TimeUpdater(Engine *e, uint8_t taskFlags = Task::SINGLETHREADED_REPEATING);
			virtual void run();

			Engine* mEngine;
		};

		friend TimeUpdater;

		Engine();
		~Engine();

		void run();
		void stop();

		void setApplication(const std::shared_ptr<app::Application>& application);

		void add(SystemPtr system);
		bool remove(SystemPtr system);

		SystemPtr load(const std::string& name);
		SystemPtr get(const std::string& name) const;

		TaskManager& getTaskManager();

		const std::shared_ptr<app::Application>& getApplication();

		const std::shared_ptr<Config>& getConfig();
		//boost::program_options::options_description& settings();

		const std::shared_ptr<core::Clock>& getClock();
		const std::shared_ptr<video::VideoSystem>& getVideo();
		const std::shared_ptr<input::Input>& getInput();

		EventChannel& events();

		const void setElapsedTime(const double& t) {  mElapsedTime =t; }
		const void setGlobalTime(const double& t) { mGlobalTime = t; }

		const double& elapsedTime() { return mElapsedTime; }
		const double& globalTime() { return mGlobalTime; }

	private:
		void initializeSystems();
		void shutdownSystems();

		std::shared_ptr<app::Application> mApplication;
		std::shared_ptr<Config> mConfig;

		std::shared_ptr<video::VideoSystem> mVideo;
		std::shared_ptr<input::Input> mInput;
		std::shared_ptr<core::Clock> mClock;


		eWindowLibraryType mWindowLibrary;

		SystemMap		mSystemMap;
		TaskManager		mTaskManager;
		EventChannel	mChannel;
		bool			mbRunning;

		double mElapsedTime; //seconds
		double mGlobalTime;  //seconds

	};
}


