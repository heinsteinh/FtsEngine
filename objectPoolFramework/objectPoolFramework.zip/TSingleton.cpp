#include "stdafx.h"
#include "TSingleton.h"


