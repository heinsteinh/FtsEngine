#include "stdafx.h"
#include "Job.h"

namespace core {

	Job::Job(JobFunction func_) :
		func(func_) {

	}

} // namespace core