#include "stdafx.h"
#include "PhongPerPixelLight.h"


