// graphicFramework.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include "ResourceManager.h"
#include "Star.h"

int _tmain(int argc, _TCHAR* argv[])
{
	zephyr::gfx::MeshPtr myStart = zephyr::gfx::makeStar(3, 6);
	
	return 0;
}

