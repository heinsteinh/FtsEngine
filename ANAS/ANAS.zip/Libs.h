/*
* Includes all relevant libraries
*/

#ifndef OA_LIBS_H
#define OA_LIBS_H

#include <ctime>
#include <deque>
#include <fstream>
#include <iostream>
#include <list>
#include <map>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <vector>
#include <algorithm>
#include <string>
#include <ostream>
#include <strstream>
#include <sstream>

#include <thread>
#include <future>
#include <functional>


#include <GLES2/gl2.h>
#include <GLES2/gl2ext.h>
#include <EGL/egl.h>
#include <EGL/eglext.h>

#pragma comment(lib,"libEGL.lib")
#pragma comment(lib, "libGLESv2.lib")



#define GL_CHECK_ \
		{ \
		GLenum glError = glGetError(); \
if (glError != GL_NO_ERROR) { \
printf("glGetError() = %i (0x%.8x) at line %i\n", glError, glError, __LINE__); \
} else{ \
		printf("gl process ok at line %i\n", __LINE__); \
} \
		}

#define GL_CHECK \
		{ \
		GLenum glError = glGetError(); \
if (glError != GL_NO_ERROR) {\
	printf("glGetError() = %i (0x%.8x) at line %i\n", glError, glError, __LINE__); \
	assert(false); \
} \
} 
	


#endif

